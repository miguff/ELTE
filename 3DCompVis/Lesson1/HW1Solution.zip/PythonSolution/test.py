import cv2
import numpy as np
import sys

# Constants
width, height = 640, 480  # Size of the window
ball_radius = 20          # Radius of the ball
platform_width, platform_height = 100, 20  # Size of the platform
ball_color = (0, 255, 0)  # Green color for the ball
platform_color = (255, 0, 0)  # Blue color for the platform
bg_color = (0, 0, 0)      # Background color (black)
fps = 60                  # Frames per second

# Initial ball position and velocity
ball_pos = np.array([width // 2, height // 2])
ball_velocity = np.array([4, 4])  # X and Y velocities


# Initial platform position and speed
platform_pos = np.array([width // 2 - platform_width // 2, height - 50])
platform_velocity = 6
print(platform_pos)
sys.exit()
# Create a blank image for the window
canvas = np.zeros((height, width, 3), dtype=np.uint8)

# Main loop to animate the ball and platform
while True:
    # Clear the canvas with the background color
    canvas[:] = bg_color

    # Move the ball
    ball_pos += ball_velocity

    # Ball collision with left and right walls
    if ball_pos[0] - ball_radius <= 0 or ball_pos[0] + ball_radius >= width:
        ball_velocity[0] *= -1  # Reverse X direction

    # Ball collision with top wall
    if ball_pos[1] - ball_radius <= 0:
        ball_velocity[1] *= -1  # Reverse Y direction

    # Ball collision with the platform
    if (platform_pos[1] <= ball_pos[1] + ball_radius <= platform_pos[1] + platform_height and
            platform_pos[0] <= ball_pos[0] <= platform_pos[0] + platform_width):
        ball_velocity[1] *= -1  # Reverse Y direction

    # Ball out of bounds (below the platform)
    if ball_pos[1] - ball_radius >= height:
        # Reset ball position and velocity
        ball_pos = np.array([width // 2, height // 2])
        ball_velocity = np.array([4, 4])

    # Move the platform
    platform_pos[0] += platform_velocity

    # Platform collision with left and right walls
    if platform_pos[0] <= 0 or platform_pos[0] + platform_width >= width:
        platform_velocity *= -1  # Reverse platform direction

    # Draw the ball
    cv2.circle(canvas, tuple(ball_pos), ball_radius, ball_color, -1)

    # Draw the platform
    cv2.rectangle(canvas, tuple(platform_pos),
                  (platform_pos[0] + platform_width, platform_pos[1] + platform_height),
                  platform_color, -1)

    # Show the canvas in the window
    cv2.imshow('Ball Bounce', canvas)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1000 // fps) & 0xFF == ord('q'):
        break

# Clean up
cv2.destroyAllWindows()
